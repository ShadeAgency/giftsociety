<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class admin_payment_settings extends Model
{
    //
}
