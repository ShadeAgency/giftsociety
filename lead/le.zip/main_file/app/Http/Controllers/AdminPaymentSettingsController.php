<?php

namespace App\Http\Controllers;

use App\Models\admin_payment_settings;
use Illuminate\Http\Request;

class AdminPaymentSettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\admin_payment_settings  $admin_payment_settings
     * @return \Illuminate\Http\Response
     */
    public function show(admin_payment_settings $admin_payment_settings)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\admin_payment_settings  $admin_payment_settings
     * @return \Illuminate\Http\Response
     */
    public function edit(admin_payment_settings $admin_payment_settings)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\admin_payment_settings  $admin_payment_settings
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, admin_payment_settings $admin_payment_settings)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\admin_payment_settings  $admin_payment_settings
     * @return \Illuminate\Http\Response
     */
    public function destroy(admin_payment_settings $admin_payment_settings)
    {
        //
    }
}
